package com.oguz.arizasilme

import android.bluetooth.*
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import android.speech.tts.TextToSpeech
import android.content.SharedPreferences
import java.io.*
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var socket: BluetoothSocket
    private lateinit var output: OutputStream
    private lateinit var input: InputStream

    private lateinit var tts: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private var sesAcik = true

    private val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("ayarlar", MODE_PRIVATE)
        sesAcik = prefs.getBoolean("sesAcik", true)

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts.language = Locale("tr", "TR")
                if (sesAcik) speak("Oğuz Bey, hoş geldiniz")
            }
        }

        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectELM() }
        findViewById<Button>(R.id.btnRead).setOnClickListener { readDTC() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearDTC() }
        findViewById<Button>(R.id.btnSound).setOnClickListener { toggleSound() }
    }

    private fun speak(text: String) {
        if (!sesAcik) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    private fun toggleSound() {
        sesAcik = !sesAcik
        prefs.edit().putBoolean("sesAcik", sesAcik).apply()
        Toast.makeText(this,
            if (sesAcik) "Sesli uyarılar açıldı" else "Sesli uyarılar kapatıldı",
            Toast.LENGTH_SHORT).show()
    }

    private fun connectELM() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        val device = adapter.bondedDevices.first { it.name.contains("ELM", true) }

        socket = device.createRfcommSocketToServiceRecord(uuid)
        socket.connect()

        output = socket.outputStream
        input = socket.inputStream

        findViewById<TextView>(R.id.txtStatus).text =
            "Durum: Bağlandı (${device.name})"
    }

    private fun send(cmd: String): String {
        output.write((cmd + "\r").toByteArray())
        Thread.sleep(600)
        val buffer = ByteArray(2048)
        val size = input.read(buffer)
        return String(buffer, 0, size)
    }

    private fun readDTC() {
        val raw = send("03")
        val codes = parseDTC(raw)

        if (codes.isNotEmpty()) {
            speak("Motor arızası algılandı")
            if (codes.any { it.startsWith("P03") }) {
                speak("Lütfen aracı durdurun")
            }
        }

        findViewById<TextView>(R.id.txtResult).text =
            if (codes.isEmpty()) "Arıza kodu yok" else codes.joinToString("\n")
    }

    private fun clearDTC() {
        send("04")
        findViewById<TextView>(R.id.txtResult).text = "Arıza kodları silindi"
    }

    private fun parseDTC(resp: String): List<String> {
        val clean = resp.replace(" ", "")
        if (!clean.startsWith("43")) return emptyList()

        val list = mutableListOf<String>()
        var i = 2
        while (i + 4 <= clean.length) {
            val b1 = clean.substring(i, i + 2).toInt(16)
            val b2 = clean.substring(i + 2, i + 4).toInt(16)
            if (b1 == 0 && b2 == 0) break

            val type = when (b1 shr 6) {
                0 -> "P"; 1 -> "C"; 2 -> "B"; else -> "U"
            }
            val code = type + String.format("%01X%02X", (b1 shr 4) and 0x3, b2)
            list.add(code)
            i += 4
        }
        return list
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
    }
}
